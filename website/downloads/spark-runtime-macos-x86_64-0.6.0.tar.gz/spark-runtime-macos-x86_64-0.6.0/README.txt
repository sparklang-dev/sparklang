Spark AI portable runtime kit — macos x86_64 (0.6.0)
==========================================================

Build bootstrap VM and sparkasm on your machine, then dry-run AI examples.

  tar xzf spark-runtime-macos-x86_64-0.6.0.tar.gz && cd spark-runtime-macos-x86_64-0.6.0 && ./build.sh
Docs: https://sparklang.dev/docs/programming-guide.html
