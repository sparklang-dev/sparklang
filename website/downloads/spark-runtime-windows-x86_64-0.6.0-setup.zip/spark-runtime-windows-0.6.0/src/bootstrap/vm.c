/* Spark C bootstrap VM — dry subset matching GAS asm/spark.s.
 * Ops: model/ask/print/let + classify/extract/tool/with/listen/speak/
 * pipeline/review/voice + browser run|goto + mitm enable +
 * engine fetch (file://) + engine parse + css + layout + paint +
 * show + render.
 * Unknown ops fail loud. Does not wrap ./spark. */
#include "vm.h"
#include "engine_css.h"
#include "engine_layout.h"
#include "engine_paint.h"
#include "engine_parse.h"
#include "engine_render.h"
#include "engine_show.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

/* Exact dry fixtures from asm/spark.s .data */
static const char DRY_SUPPORT[] =
    "{\"label\":\"support\",\"confidence\":0.91,"
    "\"reasons\":[\"dry-run\"]}";
static const char DRY_SALES[] =
    "{\"label\":\"sales\",\"confidence\":0.88,"
    "\"reasons\":[\"dry-run\"]}";
static const char DRY_SPAM[] =
    "{\"label\":\"spam\",\"confidence\":0.95,"
    "\"reasons\":[\"dry-run\"]}";
static const char DRY_PERSON[] =
    "{\"name\":\"Ada Lovelace\",\"age\":36}";
static const char DRY_TRANSCRIPT[] =
    "My washer is broken and I need support.";
static const char DRY_REV_HIGHER[] =
    "{\"issues\":[\"possible eval\",\"ai-authored patterns\"],"
    "\"complexity\":\"mid\",\"suggested_level\":\"higher\","
    "\"rationale\":\"web/JS surface — suggest high-level "
    "companion; never execute\"}";
static const char DRY_REV_LOWER[] =
    "{\"issues\":[\"hot path candidate\"],\"complexity\":\"low\","
    "\"suggested_level\":\"lower\",\"rationale\":\"asm/.s — keep "
    "machine-code level\"}";
static const char DRY_REV_MID[] =
    "{\"issues\":[\"glue boilerplate\"],\"complexity\":\"mid\","
    "\"suggested_level\":\"mid\",\"rationale\":\"Spark/C-like fit "
    "— stay on asm VM surface\"}";
/* Exact dry fragments from asm/browser_ops.s (run/goto). */
static const char BR_DEFAULT_SCRIPT[] = "examples/browser_main.spark";
static const char BR_DEFAULT_URL[] = "https://example.com/";
static const char BR_SESS_PRE[] =
    "{\"op\":\"run\",\"ok\":true,\"mode\":\"dry-run\","
    "\"session\":\"out/browser\",\"script\":\"";
static const char BR_SESS_MID[] = "\",\"url\":\"";
static const char BR_SESS_SUF[] =
    "\",\"gui\":false,\"disable_quic\":false,"
    "\"chromium_flag\":\"--enable-quic\","
    "\"note\":\"language session; GUI only via"
    " browser gui --live; QUIC on by default\"}";
static const char BR_GOTO_PRE[] = "{\"op\":\"goto\",\"ok\":true,\"url\":\"";
static const char BR_GOTO_SUF[] = "\"}";
/* Exact dry JSON from asm/browser_ops.s j_flags. */
static const char BR_FLAGS_DRY[] =
    "{\"op\":\"flags\",\"disable_quic\":false,"
    "\"default\":false,\"override\":"
    "\"mitm disable_quic on |"
    " browser gui --disable-quic\","
    "\"entrypoint\":\"spark language\"}";
/* Exact dry JSON from asm/browser_ops.s j_mitm_on. */
static const char MITM_ENABLE_DRY[] =
    "{\"op\":\"enable\",\"ok\":true,"
    "\"proxy\":\"127.0.0.1:8877\","
    "\"cdp\":\"127.0.0.1:9222\","
    "\"scope\":\"owner-local\","
    "\"owner\":\"spark-mitm-h2\","
    "\"mode\":\"dry-run-session\"}";
/* JSON fragments from asm/engine_fetch.s (file:// dry). */
static const char EF_JSON_FILE_PRE[] =
    "{\"op\":\"engine.fetch\",\"ok\":true,"
    "\"source\":\"file\",\"scheme\":\"file\","
    "\"fetched\":false,\"transport\":\"open\","
    "\"path\":\"out/engine/body.bin\","
    "\"bytes\":";
static const char EF_JSON_MID_URL[] = ",\"url\":\"";
static const char EF_JSON_END[] = "\"}";
static const char EF_BODY_PATH[] = "out/engine/body.bin";
/* Exact spine from asm/engine_pipeline.s j_fp */
static const char EF_JSON_FETCH_PARSE[] =
    "{\"op\":\"engine.fetch_parse\",\"ok\":true,"
    "\"body\":\"out/engine/body.bin\","
    "\"next\":\"engine.parse\"}";

/* Minimal RIFF stub — same bytes as asm wav_stub (48 bytes). */
static const unsigned char WAV_STUB[] = {
    'R', 'I', 'F', 'F', 0x24, 0x00, 0x00, 0x00, 'W', 'A', 'V', 'E',
    'f', 'm', 't', ' ', 0x10, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
    0x40, 0x1f, 0x00, 0x00, 0x40, 0x1f, 0x00, 0x00, 0x01, 0x00, 0x08,
    0x00, 'd', 'a', 't', 'a', 0x04, 0x00, 0x00, 0x00, 'S', 'P', 'K',
    '\n'};

static char *ltrim(char *s)
{
  while (*s == ' ' || *s == '\t')
    s++;
  return s;
}

static void rtrim(char *s)
{
  size_t n = strlen(s);
  while (n > 0 &&
         (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\r' ||
          s[n - 1] == '\n')) {
    s[--n] = '\0';
  }
}

static int kw_at(const char *line, const char *kw)
{
  size_t klen = strlen(kw);
  if (strncmp(line, kw, klen) != 0)
    return 0;
  if (line[klen] == '\0' || line[klen] == ' ' || line[klen] == '\t' ||
      line[klen] == '"' || line[klen] == '{' || line[klen] == '(')
    return 1;
  return 0;
}

/* GAS contains: case-insensitive ASCII substring. */
static int contains_ci(const char *hay, const char *needle)
{
  size_t nlen;
  size_t hlen;
  size_t i;
  size_t j;
  if (!hay || !needle || !needle[0])
    return 0;
  nlen = strlen(needle);
  hlen = strlen(hay);
  if (nlen > hlen)
    return 0;
  for (i = 0; i + nlen <= hlen; i++) {
    for (j = 0; j < nlen; j++) {
      char a = hay[i + j];
      char b = needle[j];
      if (a >= 'A' && a <= 'Z')
        a = (char)(a + 32);
      if (b >= 'A' && b <= 'Z')
        b = (char)(b + 32);
      if (a != b)
        break;
    }
    if (j == nlen)
      return 1;
  }
  return 0;
}

/* Extract first "..." with \" \\n \\t; returns malloc'd or NULL. */
static char *extract_quote(const char *line)
{
  const char *p = strchr(line, '"');
  char *out;
  size_t cap;
  size_t n = 0;
  if (!p)
    return NULL;
  p++;
  cap = strlen(p) + 1;
  out = malloc(cap);
  if (!out)
    return NULL;
  while (*p && *p != '"') {
    char c = *p++;
    if (c == '\\' && *p) {
      char e = *p++;
      if (e == 'n')
        c = '\n';
      else if (e == 't')
        c = '\t';
      else if (e == '"' || e == '\\')
        c = e;
      else
        c = e;
    }
    if (n + 1 >= cap) {
      cap *= 2;
      {
        char *nbuf = realloc(out, cap);
        if (!nbuf) {
          free(out);
          return NULL;
        }
        out = nbuf;
      }
    }
    out[n++] = c;
  }
  out[n] = '\0';
  return out;
}

static const char *arrow_name(const char *line)
{
  const char *a = strstr(line, "->");
  static char name[SPARK_VM_NAME_MAX];
  size_t i = 0;
  if (!a)
    return NULL;
  a += 2;
  while (*a == ' ' || *a == '\t')
    a++;
  while (*a && *a != ' ' && *a != '\t' && *a != '#' &&
         i + 1 < sizeof(name)) {
    name[i++] = *a++;
  }
  name[i] = '\0';
  return i ? name : NULL;
}

static void set_last(SparkVM *vm, const char *val)
{
  size_t n = strlen(val);
  if (n >= SPARK_VM_VAL_MAX)
    n = SPARK_VM_VAL_MAX - 1;
  memcpy(vm->last_val, val, n);
  vm->last_val[n] = '\0';
  vm->last_val_len = n;
}

static int vars_put(SparkVM *vm, const char *name, const char *val)
{
  int i;
  size_t nlen;
  size_t vlen;
  if (!name || !name[0])
    return -1;
  nlen = strlen(name);
  vlen = strlen(val);
  if (nlen >= SPARK_VM_NAME_MAX)
    nlen = SPARK_VM_NAME_MAX - 1;
  if (vlen >= SPARK_VM_VAL_MAX)
    vlen = SPARK_VM_VAL_MAX - 1;
  for (i = 0; i < SPARK_VM_MAX_VARS; i++) {
    if (vm->vars[i].used && strcmp(vm->vars[i].name, name) == 0) {
      memcpy(vm->vars[i].value, val, vlen);
      vm->vars[i].value[vlen] = '\0';
      return 0;
    }
  }
  for (i = 0; i < SPARK_VM_MAX_VARS; i++) {
    if (!vm->vars[i].used) {
      memcpy(vm->vars[i].name, name, nlen);
      vm->vars[i].name[nlen] = '\0';
      memcpy(vm->vars[i].value, val, vlen);
      vm->vars[i].value[vlen] = '\0';
      vm->vars[i].used = 1;
      return 0;
    }
  }
  fprintf(stderr, "error: bootstrap var table full\n");
  return -1;
}

static const char *vars_get(SparkVM *vm, const char *name)
{
  int i;
  for (i = 0; i < SPARK_VM_MAX_VARS; i++) {
    if (vm->vars[i].used && strcmp(vm->vars[i].name, name) == 0)
      return vm->vars[i].value;
  }
  return NULL;
}

static int bind_arrow(SparkVM *vm, const char *line)
{
  const char *bind = arrow_name(line);
  if (!bind)
    return 0;
  return vars_put(vm, bind, vm->last_val);
}

/* Same dry fixtures as asm/spark.s pick_ask_reply_ptr (contains = CI). */
static const char *pick_ask_reply(const char *prompt)
{
  if (contains_ci(prompt, "gravity"))
    return "Gravity pulls masses together.";
  if (contains_ci(prompt, "summar"))
    return "Summary: dry-run summary of the document.";
  if (contains_ci(prompt, "spanish"))
    return "Resumen en español (dry-run).";
  if (contains_ci(prompt, "reply"))
    return "Happy to help — what do you need?";
  return "[dry-run] model response";
}

/* Same order as asm/spark.s pick_classify_ptr (buy/price → sales,
 * broken/help/support → support, else spam if needle, else support). */
static const char *pick_classify(const char *text)
{
  if (contains_ci(text, "buy") || contains_ci(text, "price"))
    return DRY_SALES;
  if (contains_ci(text, "broken") || contains_ci(text, "help") ||
      contains_ci(text, "support"))
    return DRY_SUPPORT;
  if (contains_ci(text, "spam"))
    return DRY_SPAM;
  return DRY_SUPPORT;
}

static int looks_like_field(const char *line)
{
  const char *p = line;
  if (!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z')))
    return 0;
  p++;
  while ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
         (*p >= '0' && *p <= '9') || *p == '_')
    p++;
  return *p == ':';
}

static int op_model(SparkVM *vm, char *line)
{
  char *p = ltrim(line + 5);
  char *end;
  if (strncmp(p, "analyze", 7) == 0 || strncmp(p, "compare", 7) == 0 ||
      strncmp(p, "improve", 7) == 0 || strncmp(p, "build", 5) == 0) {
    fprintf(stderr,
            "error: model analyze|compare|improve|build is GAS-only "
            "(not in C bootstrap yet)\n");
    return 1;
  }
  end = p;
  while (*end && *end != ' ' && *end != '\t' && *end != '#')
    end++;
  *end = '\0';
  if (!p[0]) {
    fprintf(stderr, "error: model requires alias\n");
    return 1;
  }
  strncpy(vm->model_alias, p, SPARK_VM_NAME_MAX - 1);
  vm->model_alias[SPARK_VM_NAME_MAX - 1] = '\0';
  printf("[model] %s\n", vm->model_alias);
  return 0;
}

static int op_ask(SparkVM *vm, char *line)
{
  char *prompt;
  const char *reply;
  char tool_buf[SPARK_VM_VAL_MAX];
  prompt = extract_quote(line);
  if (!prompt) {
    if (strstr(line, "probe")) {
      fprintf(stderr,
              "error: ask probe is GAS-only (companion; not in C "
              "bootstrap yet)\n");
      return 1;
    }
    fprintf(stderr, "error: ask requires a quoted prompt\n");
    return 1;
  }
  printf("[ask] %s\n", prompt);
  if (vm->tools_active && vm->tool_reg_len > 0) {
    snprintf(tool_buf, sizeof(tool_buf), "[tool:%s] stub:local",
             vm->tool_reg_name);
    reply = tool_buf;
  } else {
    reply = pick_ask_reply(prompt);
  }
  printf("  → %s\n", reply);
  set_last(vm, reply);
  if (bind_arrow(vm, line) != 0) {
    free(prompt);
    return 1;
  }
  free(prompt);
  return 0;
}

static int op_print(SparkVM *vm, char *line)
{
  char *q;
  char *p;
  char name[SPARK_VM_NAME_MAX];
  size_t i = 0;
  const char *val;
  printf("[print] ");
  q = extract_quote(line);
  if (q) {
    printf("%s\n", q);
    free(q);
    return 0;
  }
  p = ltrim(line + 5);
  while (*p && *p != ' ' && *p != '\t' && *p != '#' &&
         i + 1 < sizeof(name)) {
    name[i++] = *p++;
  }
  name[i] = '\0';
  if (!name[0]) {
    printf("\n");
    return 0;
  }
  val = vars_get(vm, name);
  if (val)
    printf("%s\n", val);
  else
    printf("%s\n", name);
  return 0;
}

static int op_let(SparkVM *vm, char *line)
{
  char *p = ltrim(line + 3);
  char name[SPARK_VM_NAME_MAX];
  size_t i = 0;
  char *q;
  while (*p && *p != ' ' && *p != '\t' && *p != '=' &&
         i + 1 < sizeof(name)) {
    name[i++] = *p++;
  }
  name[i] = '\0';
  if (!name[0]) {
    fprintf(stderr, "error: let requires: let name = \"value\"\n");
    return 1;
  }
  p = ltrim(p);
  if (*p == '=')
    p = ltrim(p + 1);
  q = extract_quote(line);
  if (!q) {
    fprintf(stderr, "error: let requires: let name = \"value\"\n");
    return 1;
  }
  printf("[let] %s = %s\n", name, q);
  if (vars_put(vm, name, q) != 0) {
    free(q);
    return 1;
  }
  set_last(vm, q);
  free(q);
  (void)p;
  return 0;
}

static int op_classify(SparkVM *vm, char *line)
{
  char *q;
  const char *reply;
  printf("[classify] ");
  q = extract_quote(line);
  if (!q) {
    /* GAS cls_noq: no set_last / no bind */
    printf("\n  → %s\n", DRY_SUPPORT);
    return 0;
  }
  printf("%s\n", q);
  reply = pick_classify(q);
  printf("  → %s\n", reply);
  set_last(vm, reply);
  if (bind_arrow(vm, line) != 0) {
    free(q);
    return 1;
  }
  free(q);
  return 0;
}

static int op_extract(SparkVM *vm, char *line)
{
  /* GAS always emits dry_person; bind only if -> on this line. */
  printf("[extract] %s\n", DRY_PERSON);
  set_last(vm, DRY_PERSON);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_tool(SparkVM *vm, char *line)
{
  char *p = ltrim(line + 4);
  size_t i = 0;
  while (*p == ' ' || *p == '\t')
    p++;
  while (*p && *p != '(' && *p != ' ' && *p != '\t' &&
         i + 1 < SPARK_VM_NAME_MAX) {
    vm->tool_reg_name[i++] = *p++;
  }
  vm->tool_reg_name[i] = '\0';
  vm->tool_reg_len = i;
  if (!i) {
    fprintf(stderr, "error: tool requires a name\n");
    return 1;
  }
  printf("[tool] registered %s\n", vm->tool_reg_name);
  return 0;
}

static int op_with(SparkVM *vm, char *line)
{
  const char *lb;
  const char *rb;
  size_t n;
  if (!contains_ci(line, "tools") || vm->tool_reg_len == 0)
    goto fail;
  lb = strchr(line, '[');
  if (!lb)
    goto fail;
  lb++;
  rb = strchr(lb, ']');
  if (!rb)
    goto fail;
  n = (size_t)(rb - lb);
  if (n >= SPARK_VM_TOOL_SCOPE)
    n = SPARK_VM_TOOL_SCOPE - 1;
  memcpy(vm->tools_scope, lb, n);
  vm->tools_scope[n] = '\0';
  if (!contains_ci(vm->tools_scope, vm->tool_reg_name))
    goto fail;
  vm->tools_active = 1;
  printf("[with] {\"op\":\"with_tools\",\"tools\":\"%s\",\"active\":true}\n",
         vm->tools_scope);
  return 0;
fail:
  fprintf(stderr,
          "error: with tools [name] requires a prior"
          " tool registration and a [list]\n");
  return 1;
}

static int op_listen(SparkVM *vm, char *line)
{
  printf("[listen] %s\n", DRY_TRANSCRIPT);
  set_last(vm, DRY_TRANSCRIPT);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int write_stub_wav(const char *path)
{
  FILE *f = fopen(path, "wb");
  if (!f) {
    perror(path);
    return -1;
  }
  if (fwrite(WAV_STUB, 1, sizeof(WAV_STUB), f) != sizeof(WAV_STUB)) {
    fclose(f);
    fprintf(stderr, "error: speak stub write failed\n");
    return -1;
  }
  fclose(f);
  return 0;
}

static int op_speak(SparkVM *vm, char *line)
{
  char path[256];
  const char *arrow;
  char *q;
  (void)vm;
  if (contains_ci(line, "with") && strstr(line, "model")) {
    fprintf(stderr,
            "error: speak with model is GAS-only "
            "(voice_ops; not in C bootstrap yet)\n");
    return 1;
  }
  strncpy(path, "spark-out.wav", sizeof(path) - 1);
  path[sizeof(path) - 1] = '\0';
  arrow = strstr(line, "->");
  if (arrow) {
    q = extract_quote(arrow);
    if (q) {
      strncpy(path, q, sizeof(path) - 1);
      path[sizeof(path) - 1] = '\0';
      free(q);
    }
  }
  if (write_stub_wav(path) != 0)
    return 1;
  printf("[speak] wrote %s\n", path);
  return 0;
}

static int op_pipeline(SparkVM *vm, char *line)
{
  (void)vm;
  (void)line;
  printf("[pipeline] step\n");
  return 0;
}

/* Same heuristics as asm/spark.s pick_review_report (path/text only). */
static const char *pick_review_report(const char *line)
{
  if (contains_ci(line, ".js") || contains_ci(line, ".py") ||
      contains_ci(line, "eval"))
    return DRY_REV_HIGHER;
  if (contains_ci(line, ".spark"))
    return DRY_REV_MID;
  if (contains_ci(line, ".s"))
    return DRY_REV_LOWER;
  return DRY_REV_MID;
}

/* Second token after "voice" (mirrors asm voice_ops voice_second_token). */
static const char *voice_second_token(const char *line)
{
  static char tok[SPARK_VM_NAME_MAX];
  const char *p = line + 5;
  size_t i = 0;
  while (*p == ' ' || *p == '\t')
    p++;
  if (*p == '\0' || *p == '{' || *p == '#')
    return NULL;
  while (*p && *p != ' ' && *p != '\t' && *p != '{' && *p != '"' &&
         i + 1 < sizeof(tok)) {
    tok[i++] = *p++;
  }
  tok[i] = '\0';
  return i ? tok : NULL;
}

static int op_voice(SparkVM *vm, char *line)
{
  const char *sub;
  (void)vm;
  sub = voice_second_token(line);
  if (sub) {
    if (strcmp(sub, "review") == 0 || strcmp(sub, "code") == 0 ||
        strcmp(sub, "copy") == 0 || strcmp(sub, "model") == 0 ||
        strcmp(sub, "pstn") == 0) {
      fprintf(stderr,
              "error: voice %s is GAS-only (companion; not in C "
              "bootstrap yet)\n",
              sub);
      return 1;
    }
  }
  printf("[voice] session\n");
  return 0;
}

/* Second token after "browser" (mirrors asm browser_ops needles). */
static const char *browser_second_token(const char *line)
{
  static char tok[SPARK_VM_NAME_MAX];
  const char *p = line + 7;
  size_t i = 0;
  while (*p == ' ' || *p == '\t')
    p++;
  if (*p == '\0' || *p == '#' || *p == '"')
    return NULL;
  while (*p && *p != ' ' && *p != '\t' && *p != '"' && *p != '#' &&
         i + 1 < sizeof(tok)) {
    tok[i++] = *p++;
  }
  tok[i] = '\0';
  return i ? tok : NULL;
}

static int ensure_browser_dirs(void)
{
  if (mkdir("out", 0755) != 0 && errno != EEXIST)
    return -1;
  if (mkdir("out/browser", 0755) != 0 && errno != EEXIST)
    return -1;
  return 0;
}

static int write_session_json(SparkVM *vm, char *json, size_t jcap)
{
  FILE *f;
  int n;
  const char *script =
      vm->browser_script[0] ? vm->browser_script : BR_DEFAULT_SCRIPT;
  const char *url =
      vm->browser_url[0] ? vm->browser_url : BR_DEFAULT_URL;
  n = snprintf(json, jcap, "%s%s%s%s%s", BR_SESS_PRE, script, BR_SESS_MID,
               url, BR_SESS_SUF);
  if (n < 0 || (size_t)n >= jcap)
    return -1;
  if (ensure_browser_dirs() != 0)
    return -1;
  f = fopen("out/browser/session.json", "w");
  if (!f)
    return -1;
  if (fwrite(json, 1, (size_t)n, f) != (size_t)n) {
    fclose(f);
    return -1;
  }
  fclose(f);
  return 0;
}

static int op_browser_run(SparkVM *vm, char *line)
{
  char *q;
  char json[SPARK_VM_VAL_MAX];
  q = extract_quote(line);
  if (q) {
    strncpy(vm->browser_script, q, sizeof(vm->browser_script) - 1);
    vm->browser_script[sizeof(vm->browser_script) - 1] = '\0';
    free(q);
  } else if (!vm->browser_script[0]) {
    strncpy(vm->browser_script, BR_DEFAULT_SCRIPT,
            sizeof(vm->browser_script) - 1);
  }
  if (!vm->browser_url[0]) {
    strncpy(vm->browser_url, BR_DEFAULT_URL,
            sizeof(vm->browser_url) - 1);
  }
  vm->browser_session_on = 1;
  if (write_session_json(vm, json, sizeof(json)) != 0) {
    fprintf(stderr, "error: browser run cannot write session.json\n");
    return 1;
  }
  printf("[browser]   → %s\n", json);
  set_last(vm, json);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_browser_goto(SparkVM *vm, char *line)
{
  char *q;
  char json[SPARK_VM_VAL_MAX];
  int n;
  if (!vm->browser_session_on) {
    fprintf(stderr,
            "[browser] error: browser session required "
            "(browser run|open first)\n");
    return 1;
  }
  q = extract_quote(line);
  if (q) {
    strncpy(vm->browser_url, q, sizeof(vm->browser_url) - 1);
    vm->browser_url[sizeof(vm->browser_url) - 1] = '\0';
    free(q);
  } else if (!vm->browser_url[0]) {
    strncpy(vm->browser_url, BR_DEFAULT_URL,
            sizeof(vm->browser_url) - 1);
  }
  if (write_session_json(vm, json, sizeof(json)) != 0) {
    fprintf(stderr, "error: browser goto cannot write session.json\n");
    return 1;
  }
  n = snprintf(json, sizeof(json), "%s%s%s", BR_GOTO_PRE, vm->browser_url,
               BR_GOTO_SUF);
  if (n < 0 || (size_t)n >= sizeof(json)) {
    fprintf(stderr, "error: browser goto json overflow\n");
    return 1;
  }
  printf("[browser]   → %s\n", json);
  set_last(vm, vm->browser_url);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_browser_show(SparkVM *vm, char *line)
{
  char *q;
  char json[ES_SHOW_JSON_CAP];
  size_t print_n;

  /* Prefix like browser_ops msg_br; dry via engine_show spine. */
  printf("[browser] ");
  q = extract_quote(line);
  if (spark_bootstrap_engine_show(q, json, sizeof(json)) != 0) {
    free(q);
    return 1;
  }
  free(q);
  print_n = strlen(json);
  printf("  → %.*s\n", (int)print_n, json);
  set_last(vm, json);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_browser_flags(SparkVM *vm, char *line)
{
  /* Match asm br_flags → j_flags (no session required). */
  printf("[browser]   → %s\n", BR_FLAGS_DRY);
  set_last(vm, BR_FLAGS_DRY);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

/* Match asm br_render → engine_pipeline_render ([browser] prefix). */
static int op_browser_render(SparkVM *vm, char *line)
{
  char json[ER_RENDER_JSON_CAP];
  size_t print_n;

  printf("[browser] ");
  if (spark_bootstrap_engine_render(json, sizeof(json)) != 0)
    return 1;
  print_n = strlen(json);
  printf("  -> %.*s\n", (int)print_n, json);
  set_last(vm, json);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

/* GAS contains("render") before "engine", so
 * `browser engine render` == browser render. Other engine subs stay
 * fail-loud for now. */
static int op_browser_engine(SparkVM *vm, char *line)
{
  if (strstr(line, "render"))
    return op_browser_render(vm, line);
  fprintf(stderr,
          "error: browser engine is GAS-only except render "
          "(companion/engine; not in C bootstrap yet)\n");
  return 1;
}

static int op_browser(SparkVM *vm, char *line)
{
  const char *sub;
  sub = browser_second_token(line);
  if (!sub) {
    fprintf(stderr,
            "error: unknown browser op (want: run|goto|open|start|"
            "gui|show|flags|render|engine|cdp)\n");
    return 1;
  }
  if (strcmp(sub, "run") == 0 || strcmp(sub, "open") == 0 ||
      strcmp(sub, "start") == 0)
    return op_browser_run(vm, line);
  if (strcmp(sub, "goto") == 0)
    return op_browser_goto(vm, line);
  if (strcmp(sub, "show") == 0)
    return op_browser_show(vm, line);
  if (strcmp(sub, "flags") == 0)
    return op_browser_flags(vm, line);
  if (strcmp(sub, "render") == 0)
    return op_browser_render(vm, line);
  if (strcmp(sub, "engine") == 0)
    return op_browser_engine(vm, line);
  if (strcmp(sub, "gui") == 0) {
    fprintf(stderr,
            "[browser] error: browser gui requires --live "
            "(dry-run never launches host GUI)\n");
    return 1;
  }
  if (strcmp(sub, "cdp") == 0) {
    fprintf(stderr,
            "error: browser %s is GAS-only (companion/engine; not in "
            "C bootstrap yet)\n",
            sub);
    return 1;
  }
  fprintf(stderr,
          "error: unknown browser op (want: run|goto|open|start|"
          "gui|show|flags|render|engine|cdp)\n");
  return 1;
}

/* Second token after "mitm" (mirrors asm browser_ops needles). */
static const char *mitm_second_token(const char *line)
{
  static char tok[SPARK_VM_NAME_MAX];
  const char *p = line + 4;
  size_t i = 0;
  while (*p == ' ' || *p == '\t')
    p++;
  if (*p == '\0' || *p == '#' || *p == '"')
    return NULL;
  while (*p && *p != ' ' && *p != '\t' && *p != '"' && *p != '#' &&
         i + 1 < sizeof(tok)) {
    tok[i++] = *p++;
  }
  tok[i] = '\0';
  return i ? tok : NULL;
}

static int write_mitm_json(void)
{
  FILE *f;
  size_t n;
  if (ensure_browser_dirs() != 0)
    return -1;
  f = fopen("out/browser/mitm.json", "w");
  if (!f)
    return -1;
  n = strlen(MITM_ENABLE_DRY);
  if (fwrite(MITM_ENABLE_DRY, 1, n, f) != n) {
    fclose(f);
    return -1;
  }
  fclose(f);
  return 0;
}

static int op_mitm_enable(SparkVM *vm, char *line)
{
  /* Bootstrap is always dry — refuse in-line --live (GAS live forks
   * spark-mitm-h2; C path never does). */
  if (strstr(line, "--live")) {
    fprintf(stderr,
            "[mitm] error: mitm enable --live requires ./spark "
            "(C bootstrap is dry-only; never forks spark-mitm-h2)\n");
    return 1;
  }
  /* GAS auto-starts session if needed; match dry defaults. */
  if (!vm->browser_session_on) {
    if (!vm->browser_script[0]) {
      strncpy(vm->browser_script, BR_DEFAULT_SCRIPT,
              sizeof(vm->browser_script) - 1);
    }
    if (!vm->browser_url[0]) {
      strncpy(vm->browser_url, BR_DEFAULT_URL,
              sizeof(vm->browser_url) - 1);
    }
    vm->browser_session_on = 1;
  }
  vm->mitm_on = 1;
  if (write_mitm_json() != 0) {
    fprintf(stderr, "error: mitm enable cannot write mitm.json\n");
    return 1;
  }
  printf("[mitm]   → %s\n", MITM_ENABLE_DRY);
  set_last(vm, MITM_ENABLE_DRY);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_mitm(SparkVM *vm, char *line)
{
  const char *sub;
  sub = mitm_second_token(line);
  if (!sub) {
    fprintf(stderr,
            "error: unknown mitm op (want: enable|disable|"
            "disable_quic|filter|har|smoke|quic|ca-*)\n");
    return 1;
  }
  if (strcmp(sub, "enable") == 0)
    return op_mitm_enable(vm, line);
  /* Live / companion lanes stay GAS-only — fail loud, no invent. */
  fprintf(stderr,
          "error: mitm %s is GAS-only (companion/live; not in C "
          "bootstrap yet)\n",
          sub);
  return 1;
}

/* Second token after "engine" (mirrors engine_ops_dispatch). */
static const char *engine_second_token(const char *line)
{
  static char tok[SPARK_VM_NAME_MAX];
  const char *p = line + 6;
  size_t i = 0;
  while (*p == ' ' || *p == '\t')
    p++;
  if (*p == '\0' || *p == '#' || *p == '"')
    return NULL;
  while (*p && *p != ' ' && *p != '\t' && *p != '"' && *p != '#' &&
         i + 1 < sizeof(tok)) {
    tok[i++] = *p++;
  }
  tok[i] = '\0';
  return i ? tok : NULL;
}

static int ensure_engine_dirs(void)
{
  if (mkdir("out", 0755) != 0 && errno != EEXIST)
    return -1;
  if (mkdir("out/engine", 0755) != 0 && errno != EEXIST)
    return -1;
  return 0;
}

/* Copy local path → out/engine/body.bin; return byte count or -1. */
static long copy_to_body_bin(const char *path)
{
  FILE *in;
  FILE *out;
  char buf[4096];
  size_t n;
  long total = 0;
  if (ensure_engine_dirs() != 0)
    return -1;
  in = fopen(path, "rb");
  if (!in)
    return -1;
  out = fopen(EF_BODY_PATH, "wb");
  if (!out) {
    fclose(in);
    return -1;
  }
  while ((n = fread(buf, 1, sizeof(buf), in)) > 0) {
    if (fwrite(buf, 1, n, out) != n) {
      fclose(in);
      fclose(out);
      return -1;
    }
    total += (long)n;
  }
  if (ferror(in)) {
    fclose(in);
    fclose(out);
    return -1;
  }
  fclose(in);
  fclose(out);
  return total;
}

static int op_engine_fetch(SparkVM *vm, char *line)
{
  char *url;
  const char *path;
  char json[SPARK_VM_VAL_MAX];
  char pjson[EP_JSON_CAP];
  long bytes;
  int n;
  int want_parse;
  size_t print_n;

  /* Bootstrap is always dry — refuse in-line --live (GAS live uses
   * --allow-net + companion/sockets; C path never dials). */
  if (strstr(line, "--live")) {
    fprintf(stderr,
            "[engine] error: engine fetch --live requires ./spark "
            "(C bootstrap is dry-only; never dials / forks "
            "spark-engine-fetch-tls)\n");
    return 1;
  }
  want_parse = contains_ci(line, "parse");

  url = extract_quote(line);
  if (!url) {
    fprintf(stderr,
            "error: engine fetch needs a quoted URL "
            "(engine fetch \"URL\")\n");
    return 1;
  }

  printf("[engine] [engine.fetch] %s\n", url);

  if (strncmp(url, "https://", 8) == 0) {
    fprintf(stderr,
            "error: engine fetch: https blocked by default "
            "(no network dial).\n"
            "  Pass --allow-net to fork ./spark-engine-fetch-tls "
            "(OpenSSL BIO), or use file://\n");
    free(url);
    return 1;
  }
  if (strncmp(url, "http://", 7) == 0) {
    fprintf(stderr,
            "error: engine fetch: remote http(s) blocked by default "
            "(no network dial).\n"
            "  Pass --allow-net for http:// (asm socket) or https:// "
            "(OpenSSL BIO companion), or use file:// / a local path.\n");
    free(url);
    return 1;
  }

  if (strncmp(url, "file://", 7) == 0)
    path = url + 7;
  else
    path = url;

  bytes = copy_to_body_bin(path);
  if (bytes < 0) {
    fprintf(stderr, "error: engine fetch: cannot open local path\n");
    free(url);
    return 1;
  }

  n = snprintf(json, sizeof(json), "%s%ld%s%s%s", EF_JSON_FILE_PRE, bytes,
               EF_JSON_MID_URL, url, EF_JSON_END);
  free(url);
  if (n < 0 || (size_t)n >= sizeof(json)) {
    fprintf(stderr, "error: engine fetch json overflow\n");
    return 1;
  }
  printf("  → %s\n", json);

  if (want_parse) {
    /* Match .do_fetch_parse: parse body.bin then j_fp */
    printf("[engine] ");
    if (spark_bootstrap_engine_parse(EF_BODY_PATH, pjson,
                                     sizeof(pjson)) != 0)
      return 1;
    print_n = strlen(pjson);
    if (print_n > 512)
      print_n = 512;
    printf("  → %.*s\n", (int)print_n, pjson);
    if (print_n < strlen(pjson))
      printf("\n");
    printf("  -> %s\n", EF_JSON_FETCH_PARSE);
    /* GAS bind/print keeps fetch JSON as last (fetch_dispatch bind). */
    set_last(vm, json);
    if (bind_arrow(vm, line) != 0)
      return 1;
    return 0;
  }

  set_last(vm, json);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_engine_parse(SparkVM *vm, char *line)
{
  char *quoted;
  const char *path;
  char pathbuf[SPARK_VM_VAL_MAX];
  char json[EP_JSON_CAP];
  size_t print_n;

  quoted = extract_quote(line);
  if (quoted) {
    strncpy(pathbuf, quoted, sizeof(pathbuf) - 1);
    pathbuf[sizeof(pathbuf) - 1] = '\0';
    free(quoted);
  } else {
    strncpy(pathbuf, "engine/fixtures/hello.html",
            sizeof(pathbuf) - 1);
    pathbuf[sizeof(pathbuf) - 1] = '\0';
  }
  if (strncmp(pathbuf, "file://", 7) == 0)
    path = pathbuf + 7;
  else
    path = pathbuf;

  printf("[engine] ");
  if (spark_bootstrap_engine_parse(path, json, sizeof(json)) != 0)
    return 1;

  print_n = strlen(json);
  if (print_n > 512)
    print_n = 512;
  printf("  → %.*s\n", (int)print_n, json);
  if (print_n < strlen(json))
    printf("\n");
  set_last(vm, json);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_engine_css(SparkVM *vm, char *line)
{
  printf("[engine] ");
  if (spark_bootstrap_engine_css_attach() != 0)
    return 1;
  printf("  -> %s\n", EC_PATH);
  set_last(vm, EC_PATH);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_engine_layout(SparkVM *vm, char *line)
{
  char json[EL_JSON_CAP];
  size_t print_n;
  int fixture;
  int tbl;

  fixture = contains_ci(line, "fixture");
  printf("[engine] ");
  if (fixture) {
    if (spark_bootstrap_engine_layout_fixture(json, sizeof(json)) !=
        0)
      return 1;
  } else {
    if (spark_bootstrap_engine_layout(json, sizeof(json)) != 0)
      return 1;
  }
  print_n = strlen(json);
  if (print_n > 0 && json[print_n - 1] == '\n')
    print_n--;
  printf("  -> %.*s\n", (int)print_n, json);
  if (!fixture) {
    fflush(stdout);
    tbl = spark_bootstrap_engine_layout_emit_table();
    if (tbl == 0)
      printf("  -> ");
  }
  set_last(vm, EL_PATH);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_engine_paint(SparkVM *vm, char *line)
{
  char json[EP_PAINT_JSON_CAP];
  size_t print_n;
  int fixture;
  int boxes;

  fixture = contains_ci(line, "fixture");
  boxes = contains_ci(line, "boxes") || contains_ci(line, "layout");
  printf("[engine] ");
  if (fixture) {
    /* asm fixture prints its JSON to stdout (match GAS dispatch) */
    if (spark_bootstrap_engine_paint_fixture(json, sizeof(json)) !=
        0)
      return 1;
    set_last(vm, EP_FIXTURE_PPM);
  } else if (boxes) {
    if (spark_bootstrap_engine_paint_boxes(json, sizeof(json)) != 0)
      return 1;
    print_n = strlen(json);
    if (print_n > 0 && json[print_n - 1] == '\n')
      print_n--;
    printf("  -> %.*s\n", (int)print_n, json);
    set_last(vm, EP_PPM_PATH);
  } else {
    fprintf(stderr,
            "error: engine paint expects: engine paint fixture\n");
    return 1;
  }
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_engine_show(SparkVM *vm, char *line)
{
  char *q;
  char json[ES_SHOW_JSON_CAP];
  size_t print_n;

  printf("[engine] ");
  q = extract_quote(line);
  if (spark_bootstrap_engine_show(q, json, sizeof(json)) != 0) {
    free(q);
    return 1;
  }
  free(q);
  print_n = strlen(json);
  printf("  -> %.*s\n", (int)print_n, json);
  set_last(vm, json);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_engine_render(SparkVM *vm, char *line)
{
  char json[ER_RENDER_JSON_CAP];
  size_t print_n;

  printf("[engine] ");
  if (spark_bootstrap_engine_render(json, sizeof(json)) != 0)
    return 1;
  print_n = strlen(json);
  printf("  -> %.*s\n", (int)print_n, json);
  set_last(vm, json);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

static int op_engine(SparkVM *vm, char *line)
{
  const char *sub;
  sub = engine_second_token(line);
  if (!sub) {
    fprintf(stderr,
            "error: unknown engine op (want: fetch|parse|css|"
            "layout|paint|render|show)\n");
    return 1;
  }
  if (strcmp(sub, "fetch") == 0)
    return op_engine_fetch(vm, line);
  if (strcmp(sub, "parse") == 0)
    return op_engine_parse(vm, line);
  if (strcmp(sub, "css") == 0)
    return op_engine_css(vm, line);
  if (strcmp(sub, "layout") == 0)
    return op_engine_layout(vm, line);
  if (strcmp(sub, "paint") == 0)
    return op_engine_paint(vm, line);
  if (strcmp(sub, "render") == 0)
    return op_engine_render(vm, line);
  if (strcmp(sub, "show") == 0)
    return op_engine_show(vm, line);
  fprintf(stderr,
          "error: engine %s is GAS-only (asm engine_*; not in C "
          "bootstrap yet)\n",
          sub);
  return 1;
}

static int op_review(SparkVM *vm, char *line)
{
  char *q;
  const char *report;
  const char *heuristic;

  if (contains_ci(line, "url")) {
    fprintf(stderr,
            "error: review url is GAS-only (companion; not in C "
            "bootstrap yet)\n");
    return 1;
  }
  printf("[review] ");
  q = extract_quote(line);
  if (!q) {
    printf("\n");
    heuristic = line;
  } else if (contains_ci(line, "path")) {
    FILE *f = fopen(q, "r");
    if (!f) {
      fprintf(stderr, "error: review path cannot open file\n");
      free(q);
      return 1;
    }
    fclose(f);
    printf("%s\n", q);
    heuristic = q;
  } else {
    printf("%s\n", q);
    heuristic = q;
  }
  report = pick_review_report(heuristic);
  if (q)
    free(q);
  printf("  (static only — never eval web JS)\n");
  printf("  → %s\n", report);
  set_last(vm, report);
  if (bind_arrow(vm, line) != 0)
    return 1;
  return 0;
}

void spark_vm_init(SparkVM *vm)
{
  memset(vm, 0, sizeof(*vm));
  vm->dry_run = 1;
  strncpy(vm->model_alias, "fast", SPARK_VM_NAME_MAX - 1);
}

int spark_vm_run_line(SparkVM *vm, const char *raw)
{
  char buf[SPARK_VM_MAX_LINE];
  char *line;
  size_t n;
  if (!raw)
    return 0;
  n = strlen(raw);
  if (n >= sizeof(buf)) {
    fprintf(stderr, "error: line too long\n");
    return 1;
  }
  memcpy(buf, raw, n + 1);
  rtrim(buf);
  line = ltrim(buf);
  if (line[0] == '\0' || line[0] == '#')
    return 0;
  /* GAS: } clears with-tools; { alone is no-op; | prefixes next kw */
  if (line[0] == '}') {
    vm->tools_active = 0;
    return 0;
  }
  if (line[0] == '{')
    return 0;
  if (line[0] == '|') {
    line = ltrim(line + 1);
    if (line[0] == '\0')
      return 0;
  }

  if (kw_at(line, "model"))
    return op_model(vm, line);
  if (kw_at(line, "ask") || kw_at(line, "generate"))
    return op_ask(vm, line);
  if (kw_at(line, "print"))
    return op_print(vm, line);
  if (kw_at(line, "let"))
    return op_let(vm, line);
  if (kw_at(line, "classify"))
    return op_classify(vm, line);
  if (kw_at(line, "extract"))
    return op_extract(vm, line);
  if (kw_at(line, "tool"))
    return op_tool(vm, line);
  if (kw_at(line, "with"))
    return op_with(vm, line);
  if (kw_at(line, "listen"))
    return op_listen(vm, line);
  if (kw_at(line, "speak"))
    return op_speak(vm, line);
  if (kw_at(line, "pipeline"))
    return op_pipeline(vm, line);
  if (kw_at(line, "review"))
    return op_review(vm, line);
  if (kw_at(line, "voice"))
    return op_voice(vm, line);
  if (kw_at(line, "browser"))
    return op_browser(vm, line);
  if (kw_at(line, "mitm"))
    return op_mitm(vm, line);
  if (kw_at(line, "engine"))
    return op_engine(vm, line);

  if (line[0] == '"')
    return 0;
  if (looks_like_field(line))
    return 0;

  /* Known language keywords still GAS-only — fail loud, no invent. */
  {
    static const char *gas_only[] = {
        "builder", "implement",
        "network", "os",      "cuda",      "pcie",
        "encrypt",  "memory",  "ide",     "gateway",   "set",
        NULL};
    size_t i;
    for (i = 0; gas_only[i]; i++) {
      if (kw_at(line, gas_only[i])) {
        fprintf(stderr,
                "error: op '%s' is GAS-only (not in C bootstrap yet)\n",
                gas_only[i]);
        return 1;
      }
    }
  }
  fprintf(stderr, "error: unknown statement: %s\n", line);
  return 1;
}

int spark_vm_run_file(SparkVM *vm, const char *path)
{
  FILE *f;
  char line[SPARK_VM_MAX_LINE];
  int rc = 0;
  f = fopen(path, "r");
  if (!f) {
    perror(path);
    return 1;
  }
  printf("[spark] dry-run via C bootstrap VM\n");
  while (fgets(line, sizeof(line), f)) {
    if (spark_vm_run_line(vm, line) != 0) {
      rc = 1;
      break;
    }
  }
  fclose(f);
  if (rc == 0)
    printf("[spark] ok\n");
  return rc;
}
