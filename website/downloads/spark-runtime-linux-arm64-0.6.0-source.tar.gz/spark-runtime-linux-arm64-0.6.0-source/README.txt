Spark AI runtime — Linux arm64 (0.6.0) — source kit
==========================================================

Bootstrap + sparkasm compile on your arm64 machine (build.sh).
Nine AI examples + runtime-ai-guide.txt included.

  tar xzf spark-runtime-linux-arm64-0.6.0-source.tar.gz
  cd spark-runtime-linux-arm64-0.6.0-source
  ./build.sh
  ./bin/spark-bc examples/hello.spark

For prebuilt spark-bc + legacy GAS + full AI companions, use Linux x86_64.
Docs: https://sparklang.dev/docs/programming-guide.html
