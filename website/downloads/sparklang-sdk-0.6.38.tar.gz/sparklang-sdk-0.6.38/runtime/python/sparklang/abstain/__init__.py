"""Abstain / IDK heads for SparkLang local generate.

SELECT before SAMPLE: if p(abstain|h) ≥ τ → emit IDK + halt.
Internal = probe on frozen backbone; external = sidecar scorer.
"""

from __future__ import annotations

from sparklang.abstain.attach import attach_head, load_manifest
from sparklang.abstain.corpus import validate_corpus
from sparklang.abstain.eval import (
    run_heldout_eval,
    score_heldout,
    split_train_heldout,
)
from sparklang.abstain.export import (
    export_hiddens,
    synthetic_backbone_hidden,
    toy_backbone_hidden,
)
from sparklang.abstain.gate import GateConfig, GateDecision, select_before_sample
from sparklang.abstain.generate import live_ask, score_hidden
from sparklang.abstain.head import AbstainHead, head_from_state
from sparklang.abstain.inventable import (
    looks_inventable,
    outer_verify_or_refuse,
)
from sparklang.abstain.parse import parse_head_stmt
from sparklang.abstain.spark_hidden import (
    SparkHiddenRequest,
    SparkHiddenResponse,
    parse_request,
    parse_response,
    post_spark_hidden,
)
from sparklang.abstain.train import mark_head_quality, train_abstain_head

__all__ = [
    "AbstainHead",
    "GateConfig",
    "GateDecision",
    "SparkHiddenRequest",
    "SparkHiddenResponse",
    "attach_head",
    "export_hiddens",
    "head_from_state",
    "live_ask",
    "load_manifest",
    "looks_inventable",
    "mark_head_quality",
    "outer_verify_or_refuse",
    "parse_head_stmt",
    "parse_request",
    "parse_response",
    "post_spark_hidden",
    "run_heldout_eval",
    "score_heldout",
    "score_hidden",
    "select_before_sample",
    "split_train_heldout",
    "synthetic_backbone_hidden",
    "toy_backbone_hidden",
    "train_abstain_head",
    "validate_corpus",
]
