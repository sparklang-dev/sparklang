Spark AI runtime — Linux arm64 (0.6.0) — hybrid prebuilt
================================================================

Prebuilt aarch64 ELF: spark-bc (product CLI), spark-bootstrap (primary VM),
sparkasm, and C AI companions (ask-http, ask-probe, stt-tts, review-url).
spark-gas-legacy (x86_64 GAS asm VM) is not included — use spark-bc for dry-run.

Quick start (dry-run, no network)
---------------------------------
  sudo dpkg -i spark-runtime-linux-arm64-0.6.0.deb
  spark-bc /opt/spark/examples/hello.spark

Or tarball:
  tar xzf spark-runtime-linux-arm64-0.6.0.tar.gz && cd spark-runtime-linux-arm64-0.6.0
  ./bin/spark-bc examples/hello.spark

Docs: https://sparklang.dev/docs/programming-guide.html
