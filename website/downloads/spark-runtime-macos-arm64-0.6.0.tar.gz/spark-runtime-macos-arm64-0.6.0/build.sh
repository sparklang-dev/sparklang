#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
make -C src/bootstrap spark-bootstrap
make -C src/sparkasm
mkdir -p bin
cp src/bootstrap/spark-bootstrap src/sparkasm/sparkasm bin/
if [[ -x scripts/spark-bc ]]; then
  cp scripts/spark-bc bin/
  chmod +x bin/spark-bc
fi
echo "Built bin/spark-bootstrap and bin/sparkasm"
echo "Product CLI:"
echo "  ./bin/spark-bc examples/hello.spark"
echo "  ./bin/spark-bootstrap --dry-run examples/classify_intent.spark"
