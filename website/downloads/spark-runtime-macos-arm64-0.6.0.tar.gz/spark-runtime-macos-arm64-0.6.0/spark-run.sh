#!/usr/bin/env bash
# Run spark-bc from bin/ (compile → bc_vm when supported).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/bin"
runner=./spark-bc
if [[ ! -x "$runner" ]]; then
  runner=./spark-bootstrap
fi
args=()
for a in "$@"; do
  if [[ "$a" == examples/* && -f "$ROOT/$a" ]]; then
    args+=("$ROOT/$a")
  else
    args+=("$a")
  fi
done
exec "$runner" "${args[@]}"
