/* sparkc / spark-bootstrap — C dry-run VM (path B).
 * Optional --compare shells to ./spark for harness only. */
#include "vm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static void usage(const char *argv0)
{
  fprintf(stderr,
          "usage: %s [--dry-run] [--version] [--compare] <file.spark>\n"
          "  C bootstrap VM dry subset (model/ask/print/let +\n"
          "  classify/extract/tool/with/listen/speak/pipeline).\n"
          "  --compare: also run ./spark --dry-run (harness only).\n",
          argv0);
}

int main(int argc, char **argv)
{
  const char *path = NULL;
  int compare = 0;
  int i;
  SparkVM vm;
  int rc;

  for (i = 1; i < argc; i++) {
    if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
      usage(argv[0]);
      return 0;
    }
    if (strcmp(argv[i], "--version") == 0) {
      printf("spark-bootstrap 0.1 (C VM path B)\n");
      return 0;
    }
    if (strcmp(argv[i], "--dry-run") == 0)
      continue;
    if (strcmp(argv[i], "--live") == 0) {
      fprintf(stderr,
              "error: --live not supported in C bootstrap "
              "(use ./spark)\n");
      return 2;
    }
    if (strcmp(argv[i], "--compare") == 0) {
      compare = 1;
      continue;
    }
    if (argv[i][0] == '-') {
      fprintf(stderr, "error: unknown flag %s\n", argv[i]);
      usage(argv[0]);
      return 2;
    }
    path = argv[i];
  }

  if (!path) {
    usage(argv[0]);
    return 2;
  }

  spark_vm_init(&vm);
  rc = spark_vm_run_file(&vm, path);
  if (rc != 0)
    return rc;

  if (compare) {
    char *spargv[] = {"./spark", "--dry-run", (char *)path, NULL};
    printf("--- compare harness: ./spark --dry-run ---\n");
    if (access("./spark", X_OK) != 0) {
      fprintf(stderr,
              "error: ./spark missing for --compare "
              "(run make spark)\n");
      return 1;
    }
    execv("./spark", spargv);
    perror("execv ./spark");
    return 1;
  }
  return 0;
}
