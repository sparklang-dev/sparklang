Spark AI runtime — Windows arm64 (0.6.0)
===============================================

Portable bootstrap + sparkasm source kit with AI examples.
Run Setup.bat (or build.bat) once to compile on this machine (arm64).

After build:
  bin\spark-bootstrap --dry-run examples\hello.spark

For the full Linux x86_64 prebuilt stack (spark-ask-http, speech, gateway),
use WSL + the Linux x86_64 package or build from source.
Docs: https://sparklang.dev/docs/programming-guide.html
