@echo off
setlocal
cd /d "%~dp0"
echo Spark AI runtime — first-run build
echo ==================================
where bash >nul 2>&1
if errorlevel 1 (
  echo Git Bash or WSL is required to compile Spark on Windows.
  echo Install Git for Windows, then re-run Setup.bat
  pause
  exit /b 1
)
call build.bat
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Ready. Dry-run offline:
echo   bin\spark-bootstrap --dry-run examples\hello.spark
echo.
pause
