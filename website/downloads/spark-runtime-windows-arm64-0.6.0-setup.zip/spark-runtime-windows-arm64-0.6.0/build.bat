@echo off
setlocal
cd /d "%~dp0"
where bash >nul 2>&1
if errorlevel 1 (
  echo Git Bash or WSL required to compile Spark bootstrap on Windows.
  echo Install Git for Windows, then run: bash build.sh
  exit /b 1
)
bash build.sh
