#!/usr/bin/env bash
# Run spark from bin/ so ./spark-* companions resolve; rewrite examples/ paths.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/bin"
args=()
for a in "$@"; do
  if [[ "$a" == examples/* && -f "$ROOT/$a" ]]; then
    args+=("$ROOT/$a")
  else
    args+=("$a")
  fi
done
exec ./spark "${args[@]}"
