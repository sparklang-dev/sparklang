#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
make -C src/bootstrap spark-bootstrap
make -C src/sparkasm
mkdir -p bin
cp src/bootstrap/spark-bootstrap src/sparkasm/sparkasm bin/
echo "Built bin/spark-bootstrap and bin/sparkasm"
echo "AI dry-run:"
echo "  ./bin/spark-bootstrap --dry-run examples/hello.spark"
echo "  ./bin/spark-bootstrap --dry-run examples/classify_intent.spark"
