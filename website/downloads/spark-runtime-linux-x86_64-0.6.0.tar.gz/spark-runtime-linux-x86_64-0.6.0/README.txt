Spark AI runtime — Linux x86_64 (0.6.0) — prebuilt
========================================================

AI-first language runtime: ask, classify, extract, pipeline, model analyze,
review, voice, and encrypt-to-model gateway — in one reviewable .spark file.

Primary CLI: spark-bc (compile → bc_vm when supported) via spark-bootstrap.
Legacy GAS assembly VM: bin/spark-gas-legacy (x86_64 compare / --live only).

Quick start (dry-run, no network)
---------------------------------
  tar xzf spark-runtime-linux-x86_64-0.6.0.tar.gz
  cd spark-runtime-linux-x86_64-0.6.0
  ./bin/spark-bc examples/hello.spark
  ./bin/spark-gas-legacy --dry-run examples/hello.spark   # legacy compare

Installers: spark-runtime-linux-x86_64-0.6.0.deb
Docs: https://sparklang.dev/docs/programming-guide.html
