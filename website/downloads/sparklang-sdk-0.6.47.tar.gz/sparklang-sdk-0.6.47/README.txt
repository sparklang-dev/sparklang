SparkLang SDK + runtime + IDE + GUI + helpers pack (0.6.47)
==============================================================

Contents
--------
  bin/spark-bootstrap        CPU runtime / --compile / --run-bc
  bin/sparkc                 symlink → spark-bootstrap
  bin/spark-bc-gui           Spark IDE GUI (browse/compile/ask/weights)
  bin/spark-ide              Open workspace + language extension
  bin/spark-helper-compile   Helper: compile .spark → .sparkbc
  bin/spark-helper-decompile Helper: dump/inspect .sparkbc
  bin/spark-helper-opcodes   Opcode sheet from real OP tables
  bin/spark-helper-fixture-lint  JSONL fixture lint
  bin/spark-shadow-copy|build|verify  Isolated shadow workflows
  runtime/                   Python package, dump tools, .sparkbc
  sdk/                       Docs, headers, examples, python APIs
  ide/                       VS Code / Cursor extension + workspace
  gui/                       SPARK_BC GUI sources
  helpers/                   Compile/decompile/opcode/fixture helpers
  shadows/                   Shadow copy / build / verify scripts
  tools/                     BC dump + helpers/shadows + assorted

Quick start
-----------
  # Spark IDE GUI (requires a display + python3-tk)
  ./bin/spark-bc-gui

  # Owned spark-coder (if models/spark-coder shipped)
  ./bin/spark-code status
  ./bin/spark-code generate --prompt "Say exactly: spark" --max-new 8

  # Helpers
  ./bin/spark-helper-compile sdk/examples/spark_builder.spark /tmp/x.sparkbc
  ./bin/spark-helper-decompile /tmp/x.sparkbc
  ./bin/spark-helper-opcodes

  # Shadows (isolated rebuild)
  ./bin/spark-shadow-copy mybuild
  ./bin/spark-shadow-build mybuild
  ./bin/spark-shadow-verify mybuild

  # IDE (Cursor or VS Code)
  ./bin/spark-ide

CPU only. Never RTX PRO 6000. Does not claim beat Claude.
Owned coder brain = models/spark-coder (not Claude/HF).

Docs: https://sparklang.dev/docs/sdk-ide-download.html
       https://sparklang.dev/docs/spark-coder.html
